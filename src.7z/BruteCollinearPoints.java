import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
	ArrayList<LineSegment> lineSegments = new ArrayList<LineSegment>();
	
	public BruteCollinearPoints(Point[] points) {
		if (points == null) {
			throw new java.lang.NullPointerException();
		}
		for (int i = 0; i < points.length; i++) {
			if (points[i] == null) {
				throw new java.lang.NullPointerException();
			}
		}
		for (int i = 0; i < points.length; i++) {
			for (int j = i++; j < points.length; j++) {
				if (points[i] == points[j]) {
					throw new java.lang.IllegalArgumentException();
				}
			}
		}
		for (int i = 0; i < points.length; i++) {
			for (int j = i + 1; j < points.length; j++) {
				for (int m = j + 1; m < points.length; m++) {
					for (int k = m + 1; k < points.length; k++) {
						if (points[i].slopeTo(points[j]) == points[i].slopeTo(points[m]) && points[i].slopeTo(points[j]) == points[i].slopeTo(points[k])) {
							Point[] newPoints = new Point[4];
							newPoints[0] = points[i];
							newPoints[1] = points[j];
							newPoints[2] = points[m];
							newPoints[3] = points[k];
							Arrays.sort(newPoints, 0, 4);
							LineSegment lineSegment = new LineSegment(points[0], points[3]);
							lineSegments.add(lineSegment);								
						}
					}
				}
			}
		}
	}
	
	public int numberOfSegments() {
		return lineSegments.size();
	}
		
	public LineSegment[] segments() {
		LineSegment[] LineSegment = new LineSegment[numberOfSegments()];
		for (int i = 0; i < numberOfSegments(); i++) {
			LineSegment[i] = lineSegments.get(i);
		}
		return LineSegment;
	}
}
