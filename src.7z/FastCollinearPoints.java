import java.util.ArrayList;
import java.util.Arrays;
public class FastCollinearPoints {
    ArrayList<LineSegment> lineSegments = new ArrayList<LineSegment>();
    public FastCollinearPoints(Point[] points) {
        for (int i = 0; i < points.length; i++) {
            Point originPoint = points[i];
            Point[] otherPoints = new Point[points.length - 1 - i];
            for (int j = i + 1; j < points.length; j++) {
                otherPoints[j - i -1] = points[j];
            }
            Arrays.sort(otherPoints, 0, otherPoints.length, originPoint.slopeOrder());
            
            int j = 0;
            while (j < otherPoints.length) {
                int k = 1;
                while ((j + k < otherPoints.length) && (originPoint.slopeTo(otherPoints[j]) == originPoint.slopeTo(otherPoints[j + k]))) {
                    k++;
                }
                if (k >= 3) {
                    Point[] findPoints = new Point[k + 1];
                    findPoints[0] = originPoint;
                    for (int m = 0; m < k; m++) {
                        findPoints[m + 1] = otherPoints[j + m];
                    }
                    Arrays.sort(findPoints, 0, findPoints.length);
                    LineSegment lineSegment = new LineSegment(findPoints[0], findPoints[findPoints.length - 1]);
                    lineSegments.add(lineSegment);
                }
                j = j + k;
            }
        } 
    }
    public int numberOfSegments() {
        return lineSegments.size();
    }
        
    public LineSegment[] segments() {
        LineSegment[] LineSegment = new LineSegment[numberOfSegments()];
        for (int i = 0; i < numberOfSegments(); i++) {
            LineSegment[i] = lineSegments.get(i);
        }
        return LineSegment;
    }
    

}
